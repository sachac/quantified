default[:nginx][:conf_dir] = "/etc/nginx"
default[:development_app] = { :name => "app", :server_name => "rails.dev", :path => "/app_path"}

